package com.BookingDetailService.BookingDetails.service;

import java.util.List;
import java.util.Optional;
import java.util.UUID; // Import UUID for generating unique PNR numbers

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.BookingDetailService.BookingDetails.model.BookingDetails;
import com.BookingDetailService.BookingDetails.repository.BookingRepo;

@Service
public class BookingService implements BookingImpl{
    @Autowired
    private BookingRepo bookingDetailsRepository;
    
    public BookingDetails bookTicket(String userId, int trainId, int seatNo, String className) {
        BookingDetails bookingDetails = new BookingDetails();
        
        // Generate a unique PNR number
        String pnrNumber = generatePNR();
        
        // Set booking details
        bookingDetails.setUserId(userId);
        bookingDetails.setTrainId(trainId);
        bookingDetails.setSeatNo(seatNo);
        bookingDetails.setClassName(className);
        bookingDetails.setPnrNumber(pnrNumber); // Set the generated PNR number
        
        // Set booking status
        bookingDetails.setStatus("Booked");

        // Save booking details to the database
        return bookingDetailsRepository.save(bookingDetails);
    }
    
    public String generatePNR() {
        // Generate a random UUID and return its string representation
        return UUID.randomUUID().toString();
    }

    public List<BookingDetails> getAllBookingDetails() {
        return bookingDetailsRepository.findAll();
    }

    public Optional<BookingDetails> getBookingDetailsById(long id) {
        return bookingDetailsRepository.findById(id);
    }
  
    public void cancelTicket(long bookingId) {
        bookingDetailsRepository.deleteById(bookingId);
    }
    public BookingDetails updateBookingDetails(long id, BookingDetails bookingDetails) {
        bookingDetails.setId(id);
        return bookingDetailsRepository.save(bookingDetails);
    }

}
