package com.BookingDetailService.BookingDetails.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.BookingDetailService.BookingDetails.model.BookingDetails;
import com.BookingDetailService.BookingDetails.service.BookingService;

@RestController
@RequestMapping("/booking-details")
public class Controller {
	
	 private static final Logger logger = LoggerFactory.getLogger(Controller.class);
    @Autowired
    private BookingService bookingService;
  
    @PostMapping("/book-ticket")
    public BookingDetails bookTicket(@RequestBody BookingDetails bookingDetails) {
    	
    	 logger.info("Booking ticket for user '{}', train '{}', seat '{}', class '{}'", 
                 bookingDetails.getUserId(), bookingDetails.getTrainId(), 
                 bookingDetails.getSeatNo(), bookingDetails.getClassName());
    	 
        return bookingService.bookTicket(
                bookingDetails.getUserId(),
                bookingDetails.getTrainId(),
                bookingDetails.getSeatNo(),
                bookingDetails.getClassName()
        );
             
    }
    @GetMapping("/getbooking")
    public List<BookingDetails> getAllBookingDetails() {
    	logger.info("Fetching all booking details");
    	
        return bookingService.getAllBookingDetails();
    }

    @GetMapping("/getbooking/{id}")
    public Optional<BookingDetails> getBookingDetailsById(@PathVariable long id) {
    	logger.info("Fetching booking details for ID: {}", id);
    	
        return bookingService.getBookingDetailsById(id);
    }


    @PutMapping("updateDetail/{id}")
    public BookingDetails updateBookingDetails(@PathVariable long id, @RequestBody BookingDetails bookingDetails) {
    	logger.info("Updating booking details for ID: {}", id);
        return bookingService.updateBookingDetails(id, bookingDetails);
    }

    @DeleteMapping("cancelticket/{id}")
    public void cancelTicket(@PathVariable long id) {
    	
    	logger.info("Canceling ticket for ID: {}", id);
    	
        bookingService.cancelTicket(id);
    }
  
}