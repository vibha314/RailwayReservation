package com.BookingDetailService.BookingDetails.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class BookingDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private String userId;
    private int trainId;
    private int seatNo;
    private String className;
    private String pnrNumber;
    private String status;
   
    // Constructors, Getters, and Setters
    
    public BookingDetails(long id, String userId, int trainId, int seatNo, String className, String pnrNumber, String status) {
        this.id = id;
        this.userId = userId;
        this.trainId = trainId;
        this.seatNo = seatNo;
        this.className = className;
        this.pnrNumber = pnrNumber;
        this.status = status;
    }

    public BookingDetails() {
        super();
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public int getTrainId() {
        return trainId;
    }

    public void setTrainId(int trainId) {
        this.trainId = trainId;
    }

    public int getSeatNo() {
        return seatNo;
    }

    public void setSeatNo(int seatNo) {
        this.seatNo = seatNo;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getPnrNumber() {
        return pnrNumber;
    }

    public void setPnrNumber(String pnrNumber) {
        this.pnrNumber = pnrNumber;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

	@Override
	public String toString() {
		return "BookingDetails [id=" + id + ", userId=" + userId + ", trainId=" + trainId + ", seatNo=" + seatNo
				+ ", className=" + className + ", pnrNumber=" + pnrNumber + ", status=" + status + "]";
	}
    
}
