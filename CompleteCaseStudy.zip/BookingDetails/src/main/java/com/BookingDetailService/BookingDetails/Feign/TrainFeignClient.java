package com.BookingDetailService.BookingDetails.Feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.BookingDetailService.BookingDetails.model.TrainDetails;

@FeignClient(value="train" , url="http://localhost:9090/trains")
public interface TrainFeignClient {
	@GetMapping("/train/{train_no}")
	ResponseEntity<TrainDetails>  getTrainById(@PathVariable("train_no") int train_no);

}
