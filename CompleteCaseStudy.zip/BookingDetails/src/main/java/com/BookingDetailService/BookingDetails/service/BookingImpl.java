package com.BookingDetailService.BookingDetails.service;

import java.util.List;
import java.util.Optional;

import com.BookingDetailService.BookingDetails.model.BookingDetails;

public interface BookingImpl {


    List<BookingDetails> getAllBookingDetails();
    
    Optional<BookingDetails> getBookingDetailsById(long id);
    
    BookingDetails updateBookingDetails(long id, BookingDetails bookingDetails);
    
    void cancelTicket(long bookingId);
}
