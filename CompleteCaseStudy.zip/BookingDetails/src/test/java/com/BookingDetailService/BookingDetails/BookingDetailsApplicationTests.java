package com.BookingDetailService.BookingDetails;

import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import java.util.ArrayList;
import java.util.List;
//import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.BookingDetailService.BookingDetails.model.BookingDetails;
import com.BookingDetailService.BookingDetails.repository.BookingRepo;
import com.BookingDetailService.BookingDetails.service.BookingService;



@SpringBootTest
class BookingDetailsApplicationTests {
	
	@Mock
	BookingRepo bookingrepo;
	
	@InjectMocks
	BookingService bookingservice;
	
	@BeforeEach
	public void setUp() {
	        MockitoAnnotations.initMocks(this);
	        bookingservice = mock(BookingService.class);
	}
	
	
	
	
	 /*   @Test
	    public void testGetAllBookingDetails() {
	  
	    
	        // Create sample booking details
	    	 List<BookingDetails> bookings = new ArrayList<>();
	         bookings.add(new BookingDetails(7L, "varun123",333457 , 45, "3A","3f365356-f9a8-47d8-a620-f410d3c0671c", "Booked"));
	         
	         bookings.add(new BookingDetails(9L, "sharvari05",123564 , 90, "1A","ba1f1b87-99fe-4d80-9ac2-fdf59352e294", "Booked"));
	        		 
	    	
	        
	        // Mock the behavior of BookingRepo.findAll() method
	        when(bookingrepo.findAll()).thenReturn(bookings);

	        // Call the method to get all booking details
	        List<BookingDetails> result = bookingservice.getAllBookingDetails();

	        // Verify the result
	        assertEquals(bookings, result);
	    }
	 */   
	    @Test
	    public void testgeneratepnr() {
	    	String fakePnr = "abc123";
	    	when(bookingservice.generatePNR()).thenReturn(fakePnr);
	    	String result = bookingservice.generatePNR();
	    	assertEquals(fakePnr,result);
	    }
	    
	    
	    
	}


  
		
