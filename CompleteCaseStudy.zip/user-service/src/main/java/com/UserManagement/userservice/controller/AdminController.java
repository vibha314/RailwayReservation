package com.UserManagement.userservice.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
//import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.UserManagement.userservice.Service.AdminInterface;
import com.UserManagement.userservice.exception.ResourceNotFound;
import com.UserManagement.userservice.model.Admin;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/admin") 
public class AdminController {
	
	private static final Logger logger = LoggerFactory.getLogger(AdminController.class);

    private final AdminInterface adminService;

    @Autowired
    public AdminController(AdminInterface adminService) {
        this.adminService = adminService;
    }

    @PostMapping("/add") // 
    public ResponseEntity<Admin> addAdmin(@RequestBody Admin admin) {
    	logger.info("Adding admin: {}", admin);
    	
        Admin addedAdmin = adminService.addAdmin(admin);
        return ResponseEntity.status(HttpStatus.CREATED).body(addedAdmin); 
    }


    @GetMapping("/{adminId}") // Use path variable for resource identification
    public ResponseEntity<Admin> getAdminById(@PathVariable("adminId") String adminId) {
    	 
    	logger.info("Fetching admin with ID: {}", adminId);
        Optional<Admin> admin = adminService.getAdminById(adminId);
        if (admin.isPresent()) {
            return ResponseEntity.ok(admin.get());
        } else {
            throw new ResourceNotFound("Admin not found with ID: " + adminId); // Return 404 if admin is not found
        } 
       
    }
}
