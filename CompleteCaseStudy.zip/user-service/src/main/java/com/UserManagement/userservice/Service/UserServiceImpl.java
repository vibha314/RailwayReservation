package com.UserManagement.userservice.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.UserManagement.userservice.model.User;
import com.UserManagement.userservice.repository.UserRepo;

@Service
public class UserServiceImpl implements UserInterface{

	@Autowired(required=false)
	UserRepo repoo;

	public List<User> getAllUser() {
		
		return repoo.findAll();
	}

	@Override
	public User addUser(User user) {
		
		return repoo.save(user);
	}


	public Optional<User> getUserById(String userId) {
		
		return repoo.findById(userId);
	}
	

	
}
