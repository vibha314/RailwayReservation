package com.UserManagement.userservice.Service;

import java.util.List;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.UserManagement.userservice.model.Admin;
import com.UserManagement.userservice.repository.AdminRepo;


@Service
public class AdminServiceImpl implements AdminInterface {

	
	@Autowired
	AdminRepo repo;
	
	@Override
	public Admin addAdmin(Admin admin) {
		
		return repo.save(admin) ;
	}
	
	public List<Admin> getAllAdmin(){
		return repo.findAll();
	}


	public Optional<Admin> getAdminById(String adminId) {
		
		return repo.findById(adminId);
	}
	
	

}
