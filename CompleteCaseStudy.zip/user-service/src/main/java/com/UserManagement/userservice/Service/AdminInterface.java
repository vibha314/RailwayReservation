package com.UserManagement.userservice.Service;

import java.util.List;
import java.util.Optional;

import com.UserManagement.userservice.model.Admin;

public interface AdminInterface {

	Admin addAdmin(Admin admin);

	
	Optional<Admin> getAdminById(String adminId);


	List<Admin> getAllAdmin();

}
