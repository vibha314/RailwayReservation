package com.UserManagement.userservice.model;

import java.util.List;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

@Entity
@Table(name="UserDetails")
public class User {
	
	@Id
	@NotBlank(message = "User ID is required")
	private String userId;
	
	@NotBlank(message = "User Name is required")
	@Size(min = 2, max = 50, message = "User Name must be between 2 and 50 characters")
	private String userName;
	
	@Pattern(regexp = "^\\+(?:[0-9] ?){6,14}[0-9]$", message = "Invalid phone number format")
	private String phoneNumber;
	
	@NotBlank(message = "User Password is required")
	private String userPassword;
	
	//Constructor
	public User(String userId, String userName, String phoneNumber, String userPassword) {
		this.userId = userId;
		this.userName = userName;
		this.phoneNumber = phoneNumber;
		this.userPassword = userPassword;
	}
	//Default Constructor
	public User() {
		super();
	}

	
	//Getters and Setters 
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	
	

}
