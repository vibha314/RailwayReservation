package com.UserManagement.userservice.Service;

import java.util.List;
import java.util.Optional;

import com.UserManagement.userservice.model.User;

public interface UserInterface{

	List<User> getAllUser();

	User addUser(User user);

	
	Optional<User> getUserById(String userId);

}
