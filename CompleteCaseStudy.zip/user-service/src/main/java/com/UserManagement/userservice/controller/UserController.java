package com.UserManagement.userservice.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RestController;

import com.UserManagement.userservice.Service.UserInterface;
import com.UserManagement.userservice.exception.ResourceNotFound;
import com.UserManagement.userservice.model.User;

import jakarta.validation.Valid;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/users")
public class UserController {

	
	 // Logger instance
    private static final Logger logger = LoggerFactory.getLogger(UserController.class);
    
    // Dependency injection using constructor
    private final UserInterface userService;

    @Autowired
    public UserController(UserInterface userService) {
        this.userService = userService;
    }

    // Get all users endpoint
    @GetMapping("/userDetail")
    public ResponseEntity<List<User>> getAllUsers() {
        // Retrieve all users from the service
    	
    	logger.info("Fetching all users");
    	
        List<User> users = userService.getAllUser();
        
        if (users.isEmpty()) {
            throw new ResourceNotFound("No users found");
        }
        // Return a response entity with status OK and the list of users
        return ResponseEntity.ok(users);
    }
 // Get user by ID endpoint
    @GetMapping("/userDetail/{userId}")
    public ResponseEntity<User> getUserById(@PathVariable("userId") String userId) {
    	
    	logger.info("Fetching user with ID: {}", userId);
    	 
        // Retrieve the user by ID from the service
        Optional<User> user = userService.getUserById(userId);
        // Check if the user exists
        if (user.isPresent()) {
            return ResponseEntity.ok(user.get());
        } else {
            throw new ResourceNotFound("User not found with ID: " + userId);
        }
    }

    // Add user endpoint
    @PostMapping("/addDetail")
        public ResponseEntity<?> addUser(@Valid @RequestBody User user, BindingResult result) {
    	 
    	logger.info("Adding a new user");

    	    if (result.hasErrors()) {
    	        // If validation errors exist, return a response entity with bad request status and error details
    	        return ResponseEntity.badRequest().body(result.getAllErrors());
    	    } else {
    	        // Add the user if validation passes
    	        return ResponseEntity.status(HttpStatus.CREATED).body(userService.addUser(user));
    	    }
    	}

    
}
