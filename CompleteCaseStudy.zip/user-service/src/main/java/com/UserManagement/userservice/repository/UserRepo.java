package com.UserManagement.userservice.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.UserManagement.userservice.model.User;

public interface UserRepo extends JpaRepository<User,String >{

	

	

}
