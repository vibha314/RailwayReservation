package com.security.Userspringsecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserspringsecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserspringsecurityApplication.class, args);
		System.out.println("output");
	}

}
