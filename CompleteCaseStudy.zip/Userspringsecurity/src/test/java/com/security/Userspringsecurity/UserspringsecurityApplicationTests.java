package com.security.Userspringsecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserspringsecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
