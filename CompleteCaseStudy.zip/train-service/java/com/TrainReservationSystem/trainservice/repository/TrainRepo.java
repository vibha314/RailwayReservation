package com.TrainReservationSystem.trainservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.TrainReservationSystem.trainservice.model.TrainDetails;

@Repository
public interface TrainRepo extends JpaRepository<TrainDetails,Integer>{
	
	
}
