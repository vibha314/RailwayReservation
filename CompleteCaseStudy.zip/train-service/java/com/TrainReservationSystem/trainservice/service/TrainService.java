package com.TrainReservationSystem.trainservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.TrainReservationSystem.trainservice.model.TrainDetails;
import com.TrainReservationSystem.trainservice.repository.TrainRepo;

@Service
public class TrainService implements TrainInterface{
	
	
	@Autowired
	private TrainRepo repo;
	
	public List<TrainDetails> getAllTrainDetails(){
		return repo.findAll();
	}
		
	public Optional<TrainDetails> getTrainDetailsById(int train_no) {
		return repo.findById(train_no);
	}

	public void deleteById(int train_no) {
		
		repo.deleteById(train_no);
}
	
	public TrainDetails postTrainDetails(TrainDetails train ) {
		
		return repo.save(train);
	}
}

	

