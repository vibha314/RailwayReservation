package com.TrainReservationSystem.trainservice.service;

import java.util.List;
import java.util.Optional;

import com.TrainReservationSystem.trainservice.model.TrainDetails;

public interface TrainInterface {

    List<TrainDetails> getAllTrainDetails();
    
    Optional<TrainDetails> getTrainDetailsById(int train_no);
    
    void deleteById(int train_no);
    
    TrainDetails postTrainDetails(TrainDetails train);
}
