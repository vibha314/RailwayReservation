package com.TrainReservationSystem.trainservice.exception;


	public class TrainException extends RuntimeException {
	    public TrainException(String message) {
	        super(message);
	    }
	}
