package com.TrainReservationSystem.trainservice.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class TrainDetails {
	
	@Id
	private int train_no;
	private String trainname;
	private String source;
	private String destination ;
	private int seats;
	private double train_fare;
	
	//created constructors
	
	public TrainDetails(int train_no, String trainname, String source, String destination, int seats,
			double train_fare) {
		super();
		this.train_no = train_no;
		this.trainname = trainname;
		this.source = source;
		this.destination = destination;
		this.seats = seats;
		this.train_fare = train_fare;
	}
	
	public TrainDetails() {
		super();
	
	}
	//applied getters and setters
	
	public int getTrain_no() {
		return train_no;
	}
	

	public void setTrain_no(int train_no) {
		this.train_no = train_no;
	}
	public String getTrainname() {
		return trainname;
	}
	public void setTrainname(String trainname) {
		this.trainname = trainname;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public int getSeats() {
		return seats;
	}
	public void setSeats(int seats) {
		this.seats = seats;
	}
	public double getTrain_fare() {
		return train_fare;
	}
	public void setTrain_fare(double train_fare) {
		this.train_fare = train_fare;
	}
	
	
	

}
