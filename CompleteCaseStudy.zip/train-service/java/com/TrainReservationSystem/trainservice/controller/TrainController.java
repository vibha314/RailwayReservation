package com.TrainReservationSystem.trainservice.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.TrainReservationSystem.trainservice.exception.TrainException;
import com.TrainReservationSystem.trainservice.model.TrainDetails;
import com.TrainReservationSystem.trainservice.service.TrainService;

@RestController
@RequestMapping("/trains")
public class TrainController {
    
	
	private static final Logger logger = LoggerFactory.getLogger(TrainController.class);

    // Autowiring TrainService for dependency injection
	
    @Autowired
    private TrainService service;
    
    // GET request to retrieve all train details
    
    @GetMapping("/train")
    public List<TrainDetails> getAllTrainDetails(){
    	logger.info("Fetching all train details");
       
        return service.getAllTrainDetails();
    }
    
    // GET request to retrieve train details by train number
    
    @GetMapping("/train/{train_no}")
    public ResponseEntity<?> getTrainDetailsById(@PathVariable int train_no){
    	
    	logger.info("Fetching train details for train number: {}", train_no);
        Optional<TrainDetails> trainDetails = service.getTrainDetailsById(train_no);
        // Check if train details exist
        if (trainDetails.isPresent()) {
            return ResponseEntity.ok(trainDetails.get());
        } else {
            // Throw exception if train details not found
  
            throw new TrainException("Train details not found for train number: " + train_no);
        }
    }
    
    // DELETE request to delete train details by train number
    
    @DeleteMapping("/train/{train_no}")
    public ResponseEntity<Void> deleteTrainDetailsById(@PathVariable int train_no) {
    	logger.info("Deleting train details for train number: {}", train_no);
        service.deleteById(train_no);
        
        return ResponseEntity.ok().build();
    }
    
    // POST request to add new train details
    @PostMapping("/addtrain")
    public ResponseEntity<TrainDetails> addtrain(@RequestBody TrainDetails train) {
    	logger.info("Adding new train details: {}", train);
        // Add new train details
        TrainDetails addedTrain = service.postTrainDetails(train);
        
        // Return response with added train details and HTTP status code 201 (Created)
        return ResponseEntity.status(HttpStatus.CREATED).body(addedTrain);
    }   
}
