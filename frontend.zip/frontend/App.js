// App.js
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';


import Navbar from './Component/Navbar';
import Home from './Component/Home';
import Train from './Component/Train';
import Booking from './Component/Booking';
import About from './Component/About';
import Contact from './Component/Contact';
import Footer from './Component/Footer';

import './App.css';

function App() {
  return (
    <Router>
      <div className="App">
        <Navbar />
        <main>
          <Routes>
            <Route path="/" exact component={Home} />
            <Route path="/trains" component={Train} />
            <Route path="/booking" component={Booking} />
            <Route path="/about" component={About} />
            <Route path="/contact" component={Contact} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
}


export default App;
