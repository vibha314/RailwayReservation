import React from 'react'
import About from '../Component/About'

const About = () => {
  return (
    <div>
      <About/>
    </div>
  )
}

export default About
