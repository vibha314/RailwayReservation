// Booking.js
import React from 'react';

function Booking() {
  return (
    <section id="booking">
      <h2>Booking</h2>
      <p>Book your train tickets hassle-free.</p>
    </section>
  );
}

export default Booking;
