// Trains.js
import React from 'react';

function Trains() {
  return (
    <section id="trains">
      <h2>Trains</h2>
      <p>Explore our available trains and their schedules.</p>
    </section>
  );
}

export default Trains;
