// Home.js
import React from 'react';

function Home() {
  return (
    <section id="home" style={{  color:"white" }}>
      <h1>Welcome to Railway Booking System</h1>
      <p>Book Your Ticket At Ease</p>
      <button style={buttonStyle}>Book Now</button>
    </section>
  );
}
const buttonStyle = {
  backgroundColor: "#007bff", // Blue background color
  color: "white",             // White text color
  padding: "10px 20px",       // Padding around the text
  fontSize: "1.2em",          // Larger font size
  border: "none",             // Remove border
  borderRadius: "5px",        // Rounded corners
  cursor: "pointer",          // Show pointer on hover
  marginTop: "20px"           // Spacing from paragraph
};

export default Home;

