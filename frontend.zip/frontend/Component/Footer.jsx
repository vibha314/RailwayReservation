import React, { Component } from 'react'

class Footer extends Component {

    render() {
        return (
            <footer className="page-footer font-small" style={{ backgroundColor: '#4B4A4A', color: 'white', position: 'absolute', bottom: 0, width: '100%' }}>
                 <p>&copy; 2024 Railway Booking System. All rights reserved.</p>
            </footer>
        )
    }
}

export default Footer