// About.js
import React from 'react';

function About() {
  return (
    <section id="about">
      <h2>About Our Railway Reservation System</h2>
      <p>Welcome to our Railway Reservation System, where booking train tickets has never been easier. Whether you're planning a business trip, a family vacation, or a weekend getaway, our platform offers a seamless booking experience.</p>
      
      <h3>Our Features</h3>
      <ul>
        <li>Extensive Train Database: Access a vast database of trains covering various routes and destinations across the country.</li>
        <li>User-friendly Interface: Our intuitive interface makes it easy for users to search for trains, check seat availability, and book tickets hassle-free.</li>
        <li>Flexible Booking Options: Choose from a range of booking options, including one-way, round trip, and multi-city journeys.</li>
        <li>Secure Payment Gateway: Enjoy peace of mind with our secure payment gateway, ensuring safe and encrypted transactions.</li>
        <li>24/7 Customer Support: Our dedicated customer support team is available round the clock to assist you with any queries or concerns.</li>
      </ul>
      
      <h3>How It Works</h3>
      <p>Booking tickets with our Railway Reservation System is simple:</p>
      <ol>
        <li>Search for Trains: Enter your journey details, including origin, destination, date, and preferred class.</li>
        <li>Choose Your Train: Browse through the available trains and select the one that best fits your schedule and preferences.</li>
        <li>Book Your Ticket: Reserve your seat by providing passenger details and completing the payment process.</li>
        <li>Receive Confirmation: Once your booking is confirmed, you'll receive a confirmation email or SMS containing your ticket details.</li>
        <li>Travel with Ease: Arrive at the station on time, present your ticket, and embark on a smooth and comfortable journey.</li>
      </ol>
      
      <h3>Why Choose Us</h3>
      <p>With our Railway Reservation System, you can expect:</p>
      <ul>
        <li>Reliability: We partner with leading railway networks to provide accurate and up-to-date information.</li>
        <li>Convenience: Book tickets anytime, anywhere, using our user-friendly platform or mobile app.</li>
        <li>Accessibility: Our system is designed to cater to the needs of all passengers, including those with special requirements.</li>
        <li>Affordability: Enjoy competitive prices and exclusive deals, making travel budget-friendly.</li>
        <li>Customer Satisfaction: Your satisfaction is our priority, and we strive to deliver exceptional service at every step.</li>
      </ul>
      
      <p>Experience the convenience and reliability of our Railway Reservation System today. Happy travels!</p>
    </section>
  );
}

export default About;
